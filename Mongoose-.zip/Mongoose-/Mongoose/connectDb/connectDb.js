const dotenv = require("dotenv");
dotenv.config();
const url = process.env.URL;
const mongoose = require("mongoose");
const connectDb = async () => {
try {
 mongoose.connect(url);
console.log("db is sucessfully connected");
} catch (error) {
console.log("db connection failed");
}
};
module.exports = connectDb;