const express = require("express");
const personRoute = express.Router();
const {
    createManyPeople, getPersonsByName, getOnePersonById, getAllPersons,
    getOnePersonByFood, putPerson, deletePerson,findPeopleWhoLikePizza
} = require("../Controllers/PersonController");

 personRoute.get("/persons/name", getPersonsByName);
 personRoute.get("/persons", getAllPersons);
 personRoute.get("/persons/:id", getOnePersonById);
 personRoute.get("/persons", getOnePersonByFood);

 personRoute.put("/persons/:id", putPerson);
 personRoute.post("/persons",createManyPeople );

 personRoute.delete("/persons/name", deletePerson);

 personRoute.get("/person", findPeopleWhoLikePizza);






module.exports = personRoute;
