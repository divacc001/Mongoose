const Person = require("../models/Person");
require("dotenv").config();

// Create Many Records with model.create()
const createManyPeople = async (req, res) => {
    const arrayOfPeople=req.body
    try {
        await Person.create(arrayOfPeople);
        res.status(201).json({ message: 'People created successfully' });
    } catch (err) {
        res.status(500).send(err.message);
    }
};
const getAllPersons = async (request, response) => {
  try { 
    const persons = await Person.find();
    if (persons && persons.length > 0) {
      response.status(200).json({ persons: persons });
    } else {
      response.status(404).json({ msg: "No persons found" });
    }
  } catch (error) {
    console.error(error);
    response.status(500).json({ msg: "Error on getting persons" });
  }
};
// Use model.find() to Search Your Database
const getPersonsByName = async (req, res) => {
    const nameToFind = req.query.name;

    try { 

      const persons = await Person.find({name: nameToFind});
      if (persons && persons.length > 0) {
        res.status(200).json({ persons: persons });
      } else {
        res.status(404).json({ msg: "No persons found" });
      }
    } catch (error) {
      console.error(error);
      res.status(500).json({ msg: "Error on getting persons" });
    }
  };
  // Use model.findOne() to Return a Single Matching Document from Your Database
  const getOnePersonByFood = async (req, res) => {
    const food = req.body.FavoriteFoods;
    try {
      const foundPerson = await Person.findOne({FavoriteFoods:  { $in: food }  });
      if (foundPerson) {
        res.status(200).json({ person: foundPerson });
      } else {
        res.status(400).json({ msg: "no user found" });
      }
    } catch {
      res.status(500).json({ msg: "error on get persons" });
    }
  };
  // Use model.findById() to Search Your Database By _id
  const getOnePersonById = async (req, res) => {
    const id = req.params.id; 
    try {
      const foundPerson = await Person.findById(id); 
      if (foundPerson) {
        res.status(200).json({ person: foundPerson });
      } else {
        res.status(404).json({ msg: "No person found" }); 
      }
    } catch (error) { 
      console.error(error); 
      res.status(500).json({ msg: "Error on get one person" });
    }
  };
  // Perform Classic Updates by Running Find, Edit, then Save
  const putPerson = async (req, res) => {
    const id = req.params.id;
    const person = req.body;
    console.log(person);
    try {
      await Person.findByIdAndUpdate(id, person);
      res.status(200).json({ msg: "update sucess" });
    } catch (error) {
      res.status(500).json({ msg: "error on update user" });
    }
  };
  const deletePerson = async (req, res) => {
    const nameToDelete = req.query.name;
    try {
      await Person.remove({ name: nameToDelete });
      res.status(200).json({ msg: "delete done" });
    } catch (error) {
      res.status(500).json({ msg: "error on deleting user" });
    }
  };

  const findPeopleWhoLikePizza = async (req, res) => {
    try {
        const results = await Person.find({ FavoriteFoods: { $in: "pizza"  }})  
            .sort({ name: 1 })  
            .limit(2)  
            .select({ name: 1, FavoriteFoods: 1, age: 0 })  
            .exec();
            console.log(findPeopleWhoLikePizza);
        // Send the results as a JSON response
        console.log(results);

        res.status(200).json(results);

    } catch (error) {
        console.error("Error during query execution", error);  
    }
};



  
module.exports = {
  findPeopleWhoLikePizza,deletePerson,putPerson,createManyPeople, getPersonsByName, getOnePersonByFood, getOnePersonById, getAllPersons
  };